<?php

    if(isset($_COOKIE['name'])){
        $name = $_COOKIE['name'];
        header("Location: order.php");
    }

    if(isset($_COOKIE['telephone'])){
        $telephone = $_COOKIE['telephone'];
    }

    if(isset($_COOKIE['type'])){
        $type = $_COOKIE['type'];
    }

    if(isset($_GET['name'])){
        $name = $_GET['name'];
        setcookie('name', $name, time() + 3600);
    }

    if(isset($_GET['telephone'])){
        $telephone = $_GET['telephone'];
        setcookie('telephone', $telephone, time() + 3600);
    }

    if(isset($_GET['type'])){
        $type = $_GET['type'];
        setcookie('type', $type, time() + 3600);
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Ex 1</title>

	<link rel="stylesheet" href="./css/styles.css">
</head>
<body>

<div class="container">	
		<h2>Order Ice Cream Online</h2>
    <form class="icecream" action="" method="GET">

        <input type="text" name="name" placeholder="name">
        <input type="text" name="telephone" placeholder="telephone">
        <select name="type" id="type">
                    <option value="0" selected="selected"></option>
                    <option value="Cup">Cup</option>
                    <option value="Plain cone">Plain cone</option>
                    <option value="Sugar cone">Sugar cone</option>
                    <option value="Waffle cone">Waffle cone</option>
        </select>
        <input type="submit" value="Place Order">
    </form>
</div>
</body>
</html>