<?php

	function sum($a, $b) {
		
	}

	function question() {

	}