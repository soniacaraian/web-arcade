
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	
	<h2>Order data</h2>
	<p>Name: <?php echo $_COOKIE['name']; ?></p>
	<p>Telephone: <?php echo $_COOKIE['telephone']; ?></p>
	<p>Ice Cream <?php echo $_COOKIE['type']; ?></p>

</body>
</html>